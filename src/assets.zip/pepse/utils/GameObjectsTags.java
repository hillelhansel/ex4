package pepse.utils;

public enum GameObjectsTags {
    AVATAR,
    GROUND,
    TRUNK,
    LEAF,
    FRUIT,
    SUN,
    NIGHT,
    SUNHALO,
    SKY
}
