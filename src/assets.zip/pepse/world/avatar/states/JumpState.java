package pepse.world.avatar.states;

import danogl.gui.UserInputListener;
import pepse.utils.Constants;
import pepse.world.avatar.Animation;
import pepse.world.avatar.Avatar;
import pepse.world.avatar.AvatarState;

import java.awt.event.KeyEvent;

public class JumpState implements AvatarState {
    private static final float JUMP_VELOCITY = -650;
    private boolean spaceWasPressed;

    @Override
    public void onEnter(Avatar avatar) {
        avatar.transform().setVelocityX(0);
        avatar.renderer().setRenderable(avatar.getAnimation(Animation.AnimationType.JUMP));
        spaceWasPressed = false;
    }

    @Override
    public void update(UserInputListener input, Avatar avatar) {
        boolean spacePressed = input.isKeyPressed(KeyEvent.VK_SPACE);

        if (spacePressed && !spaceWasPressed) {

            if (avatar.isOnGround() && avatar.hasEnergy(Constants.ONE_JUMP_ENERGY_COST)) {
                avatar.consumeEnergy(Constants.ONE_JUMP_ENERGY_COST);
                avatar.transform().setVelocityY(JUMP_VELOCITY);
            }

            else if (avatar.hasEnergy(Constants.DOUBLE_JUMP_ENERGY_COST) && avatar.isFalling()) {
                avatar.consumeEnergy(Constants.DOUBLE_JUMP_ENERGY_COST);
                avatar.transform().setVelocityY(JUMP_VELOCITY);
            }
        }

        spaceWasPressed = spacePressed;
    }
}
